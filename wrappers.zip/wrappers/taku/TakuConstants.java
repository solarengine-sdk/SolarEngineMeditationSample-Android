package com.solarengine.solarengine_meditation_sample.wrappers.taku;

public class TakuConstants {

    public static String USD = "USD";
    public static String CNY = "CNY";

    //todo 需要替换为您指定的货币单位
    public static String MY_CURRENCY = CNY;
}
